package com.example.accessabilityexample

import androidx.core.view.AccessibilityDelegateCompat

class accessibility : AccessibilityDelegateCompat() {


}