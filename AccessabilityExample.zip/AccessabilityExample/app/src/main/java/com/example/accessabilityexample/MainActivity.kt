package com.example.accessabilityexample

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.core.view.AccessibilityDelegateCompat
import androidx.core.widget.addTextChangedListener
import kotlinx.android.synthetic.main.activity_main.*
import androidx.core.view.ViewCompat



class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


      //  ViewCompat.setAccessibilityDelegate(, abc())

        button.setOnClickListener {
            button.contentDescription="Log In"
        }
        button2.setOnClickListener {
            button2.contentDescription="Forgot username or password?"
        }

       edttxt.addTextChangedListener {
           edttxt.contentDescription="Username or Password "+ edttxt.text
       }


        edttxt.setOnClickListener {

        }






    }
}
