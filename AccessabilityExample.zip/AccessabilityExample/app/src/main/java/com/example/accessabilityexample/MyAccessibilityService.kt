package com.example.accessabilityexample

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.AccessibilityDelegateCompat

class MyAccessibilityService : AccessibilityService() {
    override fun onInterrupt() {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun onAccessibilityEvent(p0: AccessibilityEvent?) {
        val eventtype=p0?.eventType
        var eventText: String =" "
        when(eventtype){
            AccessibilityEvent.TYPE_VIEW_CLICKED -> eventText="Clicked"
            AccessibilityEvent.TYPE_VIEW_FOCUSED -> eventText="Focused"
            AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED -> eventText="Text Changed"
        }
        eventText=eventText + p0?.contentDescription
        Toast.makeText(applicationContext,eventText,Toast.LENGTH_LONG).show()
    }

    override fun onServiceConnected() {
        val info:AccessibilityServiceInfo= AccessibilityServiceInfo()
        info.apply {
           eventTypes=AccessibilityEvent.TYPE_VIEW_CLICKED or AccessibilityEvent.TYPE_VIEW_FOCUSED or AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED
            packageNames= arrayOf("com.example.accessabilityexample")
            feedbackType=AccessibilityServiceInfo.FEEDBACK_SPOKEN
            notificationTimeout=30
        }
        this.serviceInfo = info
    }
   }