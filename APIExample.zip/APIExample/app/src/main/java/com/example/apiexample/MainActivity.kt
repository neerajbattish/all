package com.example.apiexample

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.TextView
import android.widget.Toast
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class MainActivity : AppCompatActivity() {

    private var weatherData: TextView?=null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        weatherData=findViewById(R.id.textView)
        findViewById<View>(R.id.button).setOnClickListener {
            getcurrentdata()
        }
    }

   internal fun getcurrentdata()
    {
       val retrofit=Retrofit.Builder().baseUrl(BaseUrl)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
        val service=retrofit.create(WeatherService::class.java)
        val call =service.getCurrentWeatherData(lat, log, appid)
        call.enqueue(object : Callback<WeatherResponse> {

            override fun onFailure(call: Call<WeatherResponse>?, t: Throwable?) {
                weatherData!!.text=t?.message
            }

            override fun onResponse(
                call: Call<WeatherResponse>?,
                response: Response<WeatherResponse>?
            ) {
                if(response?.code()==200)
                {
                    val weatherResponse=response.body()
                    val stringBuilder="Country:" +
                            weatherResponse.sys!!.country +
                            "\n"+
                            "Temperature:" +
                            weatherResponse.main!!.temp +
                            "\n"+
                            "Temperature(Min):" +
                            weatherResponse.main!!.temp_min +
                            "\n"+
                            "Temperature(Max):" +
                            weatherResponse.main!!.temp_max +
                            "\n"+
                            "Humidity:" +
                            weatherResponse.main!!.humidity +
                            "\n"+
                            "Pressure:" +
                            weatherResponse.main!!.pressure
                    weatherData!!.text=stringBuilder
                }
            }
        })
    }

    companion object{
       var BaseUrl="https://openweathermap.org/"
        var appid="3a992fb3f5c23ce06bf3b7c9770c5e30"
        var log="139"
        var lat="35"
    }
}
