package com.example.loginactivity.Login.presenter

interface ILoginPresenter {

    fun onLogin(email:String, password:String)
}