package com.example.loginactivity.Login.presenter



import android.app.Activity
import androidx.appcompat.app.AppCompatActivity
import com.example.loginactivity.Login.model.UserModel
import com.example.loginactivity.Login.view.IloginView



class  LoginPresentercompl(internal var iloginView: IloginView):ILoginPresenter {
    override fun onLogin(email: String, password: String) {
       val user=UserModel(email,password)
        val loginCode=user.isDataValid()
        if(loginCode==0 )
            iloginView.onLoginMessage(0)
        else if(loginCode==1 )
            iloginView.onLoginMessage(1)
        else if(loginCode==2)
            iloginView.onLoginMessage(2)
        else if(loginCode==3)
            iloginView.onLoginMessage(3)
        else
            iloginView.onLoginMessage(-1)
    }


}