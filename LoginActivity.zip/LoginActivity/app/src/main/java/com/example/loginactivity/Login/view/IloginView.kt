package com.example.loginactivity.Login.view

interface IloginView {
    fun onLoginMessage(message:Int)
}