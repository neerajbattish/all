package com.example.loginactivity.Login.model

import android.text.TextUtils
import java.util.regex.Pattern

class UserModel(override val email:String,override val password:String) :Iuser
{
    override fun isDataValid(): Int {
        if(TextUtils.isEmpty(email))
            return 0
        else if(!Pattern.matches("[a-z].*",email))
            return 1
        else if(TextUtils.isEmpty(password))
            return 2
        else if(!Pattern.matches(".*[a-z].*",password) || !Pattern.matches(".*[A-Z].*",password)
            || !Pattern.matches(".*[0-9].*",password) || !Pattern.matches(".*[`~!@#$%^&*()\\-_=+\\\\|\\[{\\]};:'\",<.>/?].*",password) )
            return 3
        else
            return -1
    }
    //fun check
    //   override val isDataValid: Boolean
   //     get() = (!TextUtils.isEmpty(email) && password.length>6)

}