package com.example.loginactivity.Login.model

interface Iuser {
    val email:String
    val password:String
    fun isDataValid():Int
}