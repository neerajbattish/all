package com.ndscholar.myapplication.Login.presenter

interface ILoginPresenter {
    fun onLogin(email:String, password:String)
}