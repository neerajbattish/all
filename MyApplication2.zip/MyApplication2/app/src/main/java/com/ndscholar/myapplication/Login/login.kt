package com.ndscholar.myapplication.Login

import android.content.DialogInterface
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.WindowManager
import androidx.appcompat.app.AlertDialog
import com.ndscholar.myapplication.Login.presenter.ILoginPresenter
import com.ndscholar.myapplication.Login.presenter.LoginPresentercompl
import com.ndscholar.myapplication.Login.view.IloginView
import com.ndscholar.myapplication.MainActivity
import com.ndscholar.myapplication.R
import kotlinx.android.synthetic.main.activity_login.*

class login : AppCompatActivity(), IloginView {
    override fun onLoginMessage(code: Int) {
        retrivemessage(code)
    }

    fun retrivemessage(code:Int)
    {
        if(code==0)
            displaymessage(getString(R.string.username_null))
        else if(code==1)
            displaymessage(getString(R.string.username_smal))
        else if(code==2)
            displaymessage(getString(R.string.password_null))
        else if(code==3)
            displaymessage(getString(R.string.password_condition))
        else
        {
            val intent =Intent(this,MainActivity::class.java)
            startActivity(intent)
            //displaymessage(getString(R.string.log_success))
        }

    }
    fun displaymessage(mess:String)
    {
        val dialogBuilder = AlertDialog.Builder(this)
        dialogBuilder.setMessage(mess)
                .setCancelable(false)
                .setPositiveButton(R.string.btn_dialog_ok, DialogInterface.OnClickListener {
                    dialog,_ -> dialog.cancel()
                    edit_email.setText("")
                    edit_password.setText("")

                })
        val alert = dialogBuilder.create()
        alert.setTitle(R.string.alert)
        alert.show()

    }
    internal lateinit var loginPresentercompl: ILoginPresenter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN)
        getSupportActionBar()?.hide()

        loginPresentercompl= LoginPresentercompl(this)

        btn_login.setOnClickListener {
            loginPresentercompl.onLogin(edit_email.text.toString(),edit_password.text.toString())
        }



    }
}
