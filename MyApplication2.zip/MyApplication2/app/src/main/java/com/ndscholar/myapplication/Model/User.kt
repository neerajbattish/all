package com.ndscholar.myapplication.Model

data class User(val name:String,val image:Int) {
}