package com.ndscholar.myapplication.Login.model

interface Iuser {
    val email:String
    val password:String
    fun isDataValid():Int
}