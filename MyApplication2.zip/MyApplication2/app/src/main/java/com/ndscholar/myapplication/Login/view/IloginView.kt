package com.ndscholar.myapplication.Login.view

interface IloginView {
    fun onLoginMessage(message:Int)
}