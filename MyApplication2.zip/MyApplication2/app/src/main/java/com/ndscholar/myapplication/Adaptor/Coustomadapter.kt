package com.ndscholar.myapplication.Adaptor

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.ndscholar.myapplication.DetailPage
import com.ndscholar.myapplication.Main2Activity
import com.ndscholar.myapplication.Model.User
import com.ndscholar.myapplication.R
import java.util.ArrayList

class Coustomadapter (val userList: List<User>): RecyclerView.Adapter<Coustomadapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val v= LayoutInflater.from(parent.context).inflate(R.layout.list,parent,false)

       // Toast.makeText(parent.context ,parent.context.getText(),Toast.LENGTH_LONG).show()
        return ViewHolder(v)
    }

    override fun getItemCount(): Int {
        return userList.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val user: User =userList[position]
        holder.textureViewName.text=user.name
        holder.txtimage.setImageResource(user.image)

    }

    class ViewHolder(itemView: View): RecyclerView.ViewHolder(itemView)
    {
        init {
            itemView.setOnClickListener {
                // Toast.makeText(itemView.context ,"fgdfd",Toast.LENGTH_LONG).show()
                val posi = getAdapterPosition();
                if (posi == 0) {
                   val intent= Intent(itemView.context,Main2Activity::class.java)
                    itemView.context.startActivity(intent)
                }
                else
                {
                    val intent= Intent(itemView.context,DetailPage::class.java)
                    itemView.context.startActivity(intent)
                }
            }
        }
        val textureViewName=itemView.findViewById<TextView>(R.id.category_3_text)
        val txtimage=itemView.findViewById<ImageView>(R.id.upload1)
    }



}